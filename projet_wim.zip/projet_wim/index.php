<?php  
/* ------------------Appel du Kernel------------------ */
    require('Kernel.php');
    Kernel::run();
?>