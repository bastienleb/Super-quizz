<?php
   	class LogoutController {
/* ------------------ Redirection vers fermeture ------------------ */
   		public function Logout() {
   			connection::LogOut();
   		}
   	}
?>